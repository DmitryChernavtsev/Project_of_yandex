import pygame
import os
import random

pygame.init()
pygame.mixer.init()

white = (255, 255, 255)
yellow = (255, 255, 102)
black = (0, 0, 0)
red = (213, 50, 80)
green = (0, 255, 0)
blue = (50, 153, 213)

width = 600
height = 400

dis = pygame.display.set_mode((width, height))
pygame.display.set_caption('Змейка')

clock = pygame.time.Clock()

block = 10
speed = 10

font_style = pygame.font.SysFont("bahnschrift", 25)
score_font = pygame.font.SysFont("comicsansms", 35)


def load_image(name, color_key=None):
    fullname = os.path.join('data', name)
    try:
        image = pygame.image.load(fullname)
    except pygame.error as message:
        print('Не удаётся загрузить:', name)
        raise SystemExit(message)
    image = image.convert_alpha()
    if color_key is not None:
        if color_key == -1:
            color_key = image.get_at((0, 0))
        image.set_colorkey(color_key)
    return image


def start_screen():
    intro_text = ["Змейка", " ",
                  "Для управления персонажем",
                  "используйте клавиши управления", " ",
                  "Собирайте зелёные яблоки и накапливайте баллы!", " ",
                  "НО, если вы столкнётесь с краем игрового поля",
                  "или запутаетесь в клубок,",
                  "то игра закончится!"]

    fon = pygame.transform.scale(load_image('fon.jpg'), (width, height))
    dis.blit(fon, (0, 0))
    font = pygame.font.Font(None, 27)
    text_coord = 20
    for line in intro_text:
        string_rendered = font.render(line, 1, pygame.Color('black'))
        intro_rect = string_rendered.get_rect()
        text_coord += 10
        intro_rect.top = text_coord
        intro_rect.x = 10
        text_coord += intro_rect.height
        dis.blit(string_rendered, intro_rect)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            elif event.type == pygame.KEYDOWN or \
                    event.type == pygame.MOUSEBUTTONDOWN:
                return
        pygame.display.flip()


# создание рекорда
def Your_score(score):
    value = score_font.render("Очки: " + str(score), True, yellow)
    dis.blit(value, [0, 0])


def our_snake(snake_block, snake_list):
    for x in snake_list:
        pygame.draw.rect(dis, black, [x[0], x[1], snake_block, snake_block])


def message(msg, color):
    k = 6
    for ms in msg.split('\n'):
        mesg = font_style.render(ms, True, color)
        dis.blit(mesg, [width / 10, height / k])
        k -= 1


def gameLoop(speed):
    Lengths = 0
    game_over = False
    game_close = False

    x1 = width / 2
    y1 = height / 2

    x1_change = 0
    y1_change = 0

    List = []
    Length = 1

    foodx = round(random.randrange(60, width - block - 60) / 10.0) * 10.0
    foody = round(random.randrange(60, height - block - 60) / 10.0) * 10.0

    snake_fon = pygame.image.load('data/fon_game.png')
    snake_rect_fon = snake_fon.get_rect(bottomright=(width, height))
    dis.blit(snake_fon, snake_rect_fon)

    while not game_over:

        while game_close == True:
            # dis.fill(blue)
            snake_fon = pygame.image.load('data/fon_game.png')
            snake_rect_fon = snake_fon.get_rect(bottomright=(width, height))
            dis.blit(snake_fon, snake_rect_fon)

            message("Вы проиграли! \n \nВаш игровой счёт: " + str(Length - 1) + "\n"
                                                            "Нажмите клавишу C для продолжения\n"
                                                            "или Q - для ее завершения игры",
                    red)
            Your_score(Length - 1)
            pygame.display.update()

            for event in pygame.event.get():
                if event.type == pygame.KEYDOWN:
                    if event.type == pygame.QUIT:
                        game_over = True
                        game_close = False
                    if event.key == pygame.K_q:
                        game_over = True
                        game_close = False
                    if event.key == pygame.K_c:
                        speed = 10
                        gameLoop(speed)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                game_over = True
                game_close = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    x1_change = -block
                    y1_change = 0
                elif event.key == pygame.K_RIGHT:
                    x1_change = block
                    y1_change = 0
                elif event.key == pygame.K_UP:
                    y1_change = -block
                    x1_change = 0
                elif event.key == pygame.K_DOWN:
                    y1_change = block
                    x1_change = 0

        if x1 >= width - 55 or x1 < 55 or y1 >= height - 55 or y1 < 55:
            game_close = True
            pygame.mixer.music.load('music/game-over.mp3')
            pygame.mixer.music.play(1)
        x1 += x1_change
        y1 += y1_change
        # dis.fill(blue)
        snake_fon = pygame.image.load('data/fon_game.png')
        snake_rect_fon = snake_fon.get_rect(bottomright=(width, height))
        dis.blit(snake_fon, snake_rect_fon)

        pygame.draw.rect(dis, green, [foodx, foody, block, block])
        Head = []
        Head.append(x1)
        Head.append(y1)
        List.append(Head)
        if len(List) > Length:
            del List[0]

        for x in List[:-1]:
            if x == Head:
                game_close = True
                pygame.mixer.music.load('music/game-over.mp3')
                pygame.mixer.music.play(1)

        our_snake(block, List)
        Your_score(Length - 1)

        pygame.display.update()

        if x1 == foodx and y1 == foody:
            pygame.mixer.music.load('music/predmet.mp3')
            pygame.mixer.music.play(0)
            foodx = round(random.randrange(60, width - block - 60) / 10.0) * 10.0
            foody = round(random.randrange(60, height - block - 60) / 10.0) * 10.0
            Length += 1
            Lengths += 1

        if Lengths // 5 == 1:
            pygame.mixer.music.load('music/turbo-skorost.mp3')
            pygame.mixer.music.play(0)
            Lengths = 0
            speed += 2

        clock.tick(speed)

    pygame.quit()


start_screen()
gameLoop(speed)
